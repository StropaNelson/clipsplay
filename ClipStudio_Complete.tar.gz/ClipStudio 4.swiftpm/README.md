# ClipStudio - Editor de Vídeos para Criação de Episódios

Aplicativo nativo para iPad/iPhone desenvolvido com SwiftUI e AVFoundation para transformar vídeos longos em séries de episódios com introduções, recapitulações e encerramentos.

## Estrutura do Projeto

```
ClipStudio/
├── Package.swift              # Configuração do Swift Package
├── App/
│   ├── ClipStudioApp.swift    # Entry point (@main)
│   ├── ContentView.swift      # View principal (roteador)
│   ├── Assets.xcassets/       # Assets e App Icon
│   ├── Models/
│   │   └── Project.swift      # Modelos de dados (Project, Episode, VideoSegment, etc.)
│   ├── Views/
│   │   ├── HomeView.swift     # Gerenciamento de projetos
│   │   ├── EditorView.swift   # Editor principal
│   │   ├── EpisodeListView.swift
│   │   ├── MediaLibraryView.swift
│   │   ├── TimelineView.swift
│   │   ├── ExportView.swift
│   │   ├── PreviewPlayer.swift
│   │   └── ShareSheet.swift
│   └── Services/
│       ├── ProjectStorage.swift    # Persistência JSON
│       ├── VideoImporter.swift     # Importação de mídia
│       ├── VideoProcessor.swift    # Processamento AVFoundation
│       ├── TimelineEngine.swift    # Lógica de timeline
│       ├── ExportManager.swift     # Exportação em lote
│       ├── CoverGenerator.swift    # Geração de capas
│       └── SimpleZIP.swift         # Criação de arquivos ZIP
└── Resources/
    ├── Templates/             # Templates de capas
    └── Assets/                # Assets adicionais
```

## Funcionalidades Implementadas

### ✅ Fase 1 - Fundação
- [x] Importação de vídeos (Arquivos, Galeria)
- [x] Reprodução com AVPlayer
- [x] Informações do vídeo (duração, resolução, FPS)
- [x] Seleção de intervalos (início/fim)
- [x] Exportação de trechos em MP4

### ✅ Fase 2 - Episódios
- [x] Divisão automática sequencial sem lacunas
- [x] Configuração de duração por episódio
- [x] Geração de episódios com numeração
- [x] Introdução reutilizável (global ou por episódio)
- [x] Recapitulação (manual e automática - final do episódio anterior)
- [x] Encerramento reutilizável
- [x] Modelos de segmento (SegmentTemplate)

### ✅ Fase 3 - Timeline
- [x] Timeline multipista visual (Intro, Recap, Principal, Outro, Áudio, Overlay)
- [x] Régua de tempo com marcações
- [x] Miniaturas dos segmentos
- [x] Zoom (pinch/buttons) e navegação horizontal
- [x] Playhead arrastável com sincronização de preview
- [x] Seleção e edição de segmentos (início, duração, origem)
- [x] Arraste de segmentos na timeline
- [x] Validação de sobreposição e limites

### ✅ Fase 4 - Edição Avançada
- [x] Biblioteca de mídia (vídeos, áudios, imagens)
- [x] Proporções: Original, 16:9, 9:16, 1:1, 4:5, 3:4
- [x] Resoluções: Original, 480p, 720p, 1080p, 1440p, 2160p
- [x] Enquadramento: Ajustar (fit) / Preencher (fill)
- [x] Preservação de orientação e transform

### ✅ Fase 5 - Capas e Projetos
- [x] Gerenciamento de projetos (criar, abrir, duplicar, excluir)
- [x] Persistência automática em JSON
- [x] Capas: Modelo padrão, Captura de quadro, Imagem personalizada
- [x] Capas exportadas separadamente (JPG)

### ✅ Fase 6 - Exportação Completa
- [x] Exportação individual de episódios
- [x] Exportação em lote (todos ou selecionados)
- [x] Progresso detalhado por episódio
- [x] Geração de ZIP com episódios + capas
- [x] Compartilhamento via Share Sheet
- [x] Tratamento de erros por episódio

## Requisitos

- iPad com iPadOS 16.0+ ou iPhone com iOS 16.0+
- Chip Apple Silicon (recomendado para performance de vídeo)
- Swift Playgrounds 4.0+

## Como Abrir no Swift Playgrounds

1. **No iPad**: Abra o app **Swift Playgrounds**
2. Toque em **"+"** (Novo Playground) → **"App"** → **"Navegar"**
3. Selecione a pasta `ClipStudio 4.swiftpm` 
4. Toque em **"Criar"**
5. O projeto abrirá - toque em ▶️ (Executar) na barra superior

### Alternativa: Arquivo .swiftpm
Se o Swift Playgrounds não abrir a pasta diretamente:
1. Compacte a pasta `ClipStudio 4.swiftpm` em `.zip`
2. Renomeie para `ClipStudio.swiftpm`
3. Toque no arquivo no app Arquivos → "Abrir no Swift Playgrounds"

## Uso Básico

1. **Criar Projeto**: Toque em "+" → "Novo Projeto" → dê um nome
2. **Importar Vídeo**: Na aba "Episódios", toque em "Importar vídeo" e selecione um arquivo longo
3. **Configurar Episódios**: Ajuste a duração (ex: 60s) → veja a prévia da divisão
4. **Adicionar Elementos**: Vá na aba "Elementos"
   - Ative "Introdução" → selecione início/fim do vídeo original OU importe um vídeo separado
   - Ative "Recapitulação" → escolha Manual (trechos) ou Automático (final do anterior)
   - Ative "Encerramento" → configure同様
5. **Timeline**: Aba "Timeline" → visualize faixas, arraste segmentos, ajuste playhead
6. **Exportar**: Aba "Exportar" → escolha formato/resolução → "Exportar Todos"
7. **Compartilhar**: Toque em "Criar ZIP" → compartilhe via AirDrop, Arquivos, etc.

## Arquitetura Técnica

### Modelos (Models/)
- `Project` - Projeto completo com metadados, episódios, assets, configurações
- `Episode` - Episódio individual com segmentos (intro, recap, principal, outro)
- `VideoSegment` - Segmento de vídeo com timecodes e origem
- `MediaAsset` - Asset de mídia importado (video/audio/image)
- `SegmentTemplate` - Template reutilizável para intro/outro/recap
- `RecapSettings`, `CoverSettings`, `ExportSettings` - Configurações tipadas

### Serviços (Services/)
- `ProjectStorage` - Actor para persistência JSON assíncrona
- `VideoImporter` - Importação e cópia para sandbox, geração de thumbnails
- `VideoProcessor` - Composição AVFoundation, exportação, videoComposition
- `TimelineEngine` - Lógica de timeline, validação, composição de preview
- `ExportManager` - Orquestração de exportação em lote com progresso
- `CoverGenerator` - Geração de capas (template, frame, imagem)
- `SimpleZIP` - Criação de ZIP (método Store, sem compressão)

### Views (Views/)
- `HomeView` - Lista de projetos, criar/importar/duplicar/excluir
- `EditorView` - Editor principal com tabs (Episódios, Elementos, Timeline, Exportar)
- `EpisodeListView` - Lista de episódios com badges de segmentos
- `MediaLibraryView` - Grid de assets com filtros e ações
- `TimelineView` - Timeline multipista com zoom, playhead, drag-and-drop
- `ExportView` - Configurações de exportação e seleção de episódios
- `PreviewPlayerView` - Player integrado com controles

## Limitações Conhecidas

1. **Performance em iPad antigo**: Vídeos 4K longos podem demorar para exportar
2. **Sem undo/redo na timeline**: Planejado para próxima versão
3. **Sem transições (crossfade)**: Apenas cortes diretos entre segmentos
4. **Áudio**: Mixagem básica; sem controle de volume por faixa
5. **Legendas/Textos**: Estrutura preparada (track overlay) mas UI não implementada
5. **Android**: Não implementado (requer Kotlin + Media3/MediaCodec)

## Compatibilidade

- ✅ iPadOS 16.0+
- ✅ iOS 16.0+ (iPhone)
- ✅ Apple Silicon (M1/M2/M3/M4)
- ⚠️ Intel Mac (via Mac Catalyst - não testado)

## Licença

Projeto proprietário - ClipStudio